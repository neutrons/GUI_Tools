from distutils.core import setup

setup(name = 'code',
      scripts=['scripts/run_me'],
      version = '1.0',
      author = 'Jean Bilheux',
      packages = ['code','code.thread'],
      )