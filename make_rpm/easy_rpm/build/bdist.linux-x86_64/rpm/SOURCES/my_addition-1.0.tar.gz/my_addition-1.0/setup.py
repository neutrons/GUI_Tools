from distutils.core import setup

setup(name = 'my_addition',
      scripts=['scripts/my_add'],
      version = '1.0',
      author = 'Jean Bilheux',
      packages = ['my_addition'],
      )

      